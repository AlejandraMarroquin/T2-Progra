import java.util.ArrayList;
import java.util.Scanner;

public class NombreDelMes {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        ArrayList<String> meses = new ArrayList<>();
        meses.add("Enero");
        meses.add("Febrero");
        meses.add("Marzo");
        meses.add("Abril");
        meses.add("Mayo");
        meses.add("Junio");
        meses.add("Julio");
        meses.add("Agosto");
        meses.add("Septiembre");
        meses.add("Octubre");
        meses.add("Noviembre");
        meses.add("Diciembre");
        
        System.out.print("Ingrese el número del mes (1-12): ");
        int numeroMes = scanner.nextInt();
        
        if (numeroMes >= 1 && numeroMes <= 12) {
            String nombreMes = meses.get(numeroMes - 1);
            System.out.println("El nombre del mes es: " + nombreMes);
        } else {
            System.out.println("Número de mes no válido. Por favor, ingrese un número entre 1 y 12.");
        }
        
        scanner.close();
    }
}
