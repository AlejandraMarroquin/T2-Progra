import java.util.Scanner;

public class PositivoONegativo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Ingrese un número entero: ");
        int numero = scanner.nextInt();
        
        String[] resultados = {"El número es negativo.", "El número es cero.", "El número es positivo."};
        int indice = (numero > 0) ? 2 : (numero < 0) ? 0 : 1;
        
        System.out.println(resultados[indice]);
        
        scanner.close();
    }
}
