import java.util.Scanner;

public class VerificarEdad {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Ingrese su edad: ");
        int edad = scanner.nextInt();
        
        String resultado = (edad >= 18) ? "Eres mayor de edad." : "Eres menor de edad.";
        System.out.println(resultado);
        
        scanner.close();
    }
}
